class Logger:

    @staticmethod
    def log(string):
        print("[LOG] " + string)