
# TODO make an actual profanity check here. Maybe query google? It can do that.

def has_profanity(phrase):
    return False